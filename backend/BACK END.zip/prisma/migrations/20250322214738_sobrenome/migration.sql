/*
  Warnings:

  - Added the required column `sobre_nome` to the `Usuario` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Usuario" ADD COLUMN     "sobre_nome" TEXT NOT NULL;
