-- DropForeignKey
ALTER TABLE "Certificado" DROP CONSTRAINT "Certificado_fk_id_usuario_fkey";

-- AlterTable
ALTER TABLE "Usuario" ALTER COLUMN "senha" DROP NOT NULL;

-- AddForeignKey
ALTER TABLE "Certificado" ADD CONSTRAINT "Certificado_fk_id_usuario_fkey" FOREIGN KEY ("fk_id_usuario") REFERENCES "Usuario"("id_usuario") ON DELETE CASCADE ON UPDATE CASCADE;
