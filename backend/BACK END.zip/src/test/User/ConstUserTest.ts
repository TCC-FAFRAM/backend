export const usuarios = [
  { 
    nome: 'João Silva',
    email: 'joao.silva@email.com',
    senha: 'senha123',
  },
  { 
    nome: 'Maria Oliveira',
    email: 'maria.oliveira@email.com',
    senha: 'senha456',
  },
  { 
    nome: 'Carlos Souza',
    email: 'carlos.souza@email.com',
    senha: 'senha789',
  },
  { 
    nome: 'Ana Costa',
    email: 'ana.costa@email.com',
    senha: 'senha321',
  },
  { 
    nome: 'José Santos',
    email: 'jose.santos@email.com',
    senha: 'senha654',
  },
  { 
    nome: 'Fernanda Almeida',
    email: 'fernanda.almeida@email.com',
    senha: 'senha987',
  },
  { 
    nome: 'Paulo Pereira',
    email: 'paulo.pereira@email.com',
    senha: 'senha159',
  },
  { 
    nome: 'Juliana Ribeiro',
    email: 'juliana.ribeiro@email.com',
    senha: 'senha258',
  },
  { 
    nome: 'Ricardo Lima',
    email: 'ricardo.lima@email.com',
    senha: 'senha369',
  },
  { 
    nome: 'Cláudia Martins',
    email: 'claudia.martins@email.com',
    senha: 'senha741',
  },
  { 
    nome: 'Eduardo Rocha',
    email: 'eduardo.rocha@email.com',
    senha: 'senha852',
  },
  { 
    nome: 'Luciana Barbosa',
    email: 'luciana.barbosa@email.com',
    senha: 'senha963',
  },
  { 
    nome: 'Marcos Silva',
    email: 'marcos.silva@email.com',
    senha: 'senha159',
  },
  { 
    nome: 'Letícia Ferreira',
    email: 'leticia.ferreira@email.com',
    senha: 'senha753',
  },
  { 
    nome: 'Tiago Lima',
    email: 'tiago.lima@email.com',
    senha: 'senha951',
  },
  { 
    nome: 'Simone Costa',
    email: 'simone.costa@email.com',
    senha: 'senha357',
  },
  { 
    nome: 'Fábio Souza',
    email: 'fabio.souza@email.com',
    senha: 'senha468',
  },
  { 
    nome: 'Paula Santos',
    email: 'paula.santos@email.com',
    senha: 'senha579',
  },
  { 
    nome: 'Roberto Pereira',
    email: 'roberto.pereira@email.com',
    senha: 'senha680',
  },
  { 
    nome: 'Karine Almeida',
    email: 'karine.almeida@email.com',
    senha: 'senha791',
  },
  { 
    nome: 'Gustavo Oliveira',
    email: 'gustavo.oliveira@email.com',
    senha: 'senha802',
  },
  { 
    nome: 'Marina Costa',
    email: 'marina.costa@email.com',
    senha: 'senha913',
  },
  { 
    nome: 'Vítor Ribeiro',
    email: 'vitor.ribeiro@email.com',
    senha: 'senha024',
  },
  { 
    nome: 'Luciana Rocha',
    email: 'luciana.rocha@email.com',
    senha: 'senha135',
  },
  { 
    nome: 'Renato Lima',
    email: 'renato.lima@email.com',
    senha: 'senha246',
  },
  { 
    nome: 'Tatiane Martins',
    email: 'tatiane.martins@email.com',
    senha: 'senha357',
  },
  { 
    nome: 'José Almeida',
    email: 'jose.almeida@email.com',
    senha: 'senha468',
  },
  { 
    nome: 'Juliana Pereira',
    email: 'juliana.pereira@email.com',
    senha: 'senha579',
  },
  { 
    nome: 'Lucas Santos',
    email: 'lucas.santos@email.com',
    senha: 'senha680',
  },
  { 
    nome: 'Raquel Souza',
    email: 'raquel.souza@email.com',
    senha: 'senha791',
  },
  { 
    nome: 'Rafael Lima',
    email: 'rafael.lima@email.com',
    senha: 'senha802',
  },
  { 
    nome: 'Marta Ferreira',
    email: 'marta.ferreira@email.com',
    senha: 'senha913',
  },
  { 
    nome: 'Carlos Barbosa',
    email: 'carlos.barbosa@email.com',
    senha: 'senha024',
  },
  { 
    nome: 'Cláudia Lima',
    email: 'claudia.lima@email.com',
    senha: 'senha135',
  },
  { 
    nome: 'André Souza',
    email: 'andre.souza@email.com',
    senha: 'senha246',
  },
  { 
    nome: 'Renata Martins',
    email: 'renata.martins@email.com',
    senha: 'senha357',
  },
  { 
    nome: 'Lúcia Pereira',
    email: 'lucia.pereira@email.com',
    senha: 'senha468',
  },
  { 
    nome: 'Simone Almeida',
    email: 'simone.almeida@email.com',
    senha: 'senha579',
  },
  { 
    nome: 'César Ribeiro',
    email: 'cesar.ribeiro@email.com',
    senha: 'senha680',
  },
  { 
    nome: 'Eduarda Lima',
    email: 'eduarda.lima@email.com',
    senha: 'senha791',
  },
  { 
    nome: 'Vera Souza',
    email: 'vera.souza@email.com',
    senha: 'senha802',
  },
  { 
    nome: 'Tiago Pereira',
    email: 'tiago.pereira@email.com',
    senha: 'senha913',
  },
  { 
    nome: 'Roberta Costa',
    email: 'roberta.costa@email.com',
    senha: 'senha024',
  },
  { 
    nome: 'Rogério Ribeiro',
    email: 'rogerio.ribeiro@email.com',
    senha: 'senha135',
  },
  { 
    nome: 'Juliano Rocha',
    email: 'juliano.rocha@email.com',
    senha: 'senha246',
  },
  { 
    nome: 'Marcos Pereira',
    email: 'marcos.pereira@email.com',
    senha: 'senha357',
  },
  { 
    nome: 'Sérgio Lima',
    email: 'sergio.lima@email.com',
    senha: 'senha468',
  },
  { 
    nome: 'Tatiane Souza',
    email: 'tatiane.souza@email.com',
    senha: 'senha579',
  },
  { 
    nome: 'Vanessa Almeida',
    email: 'vanessa.almeida@email.com',
    senha: 'senha680',
  },
  { 
    nome: 'Ricardo Costa',
    email: 'ricardo.costa@email.com',
    senha: 'senha791',
  }
];
